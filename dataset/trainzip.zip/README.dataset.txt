# My First Project > 2025-09-24 11:38am
https://universe.roboflow.com/shaarifzaid/my-first-project-sunrm

Provided by a Roboflow user
License: CC BY 4.0

